package labrat.com.amigo;

/**
 * Created by garvi on 5/7/2017.
 */

public class PayPalConfig {
    public static final String PAYPAL_CLIENT_ID = "AWn3uyQ7XmyGM0x0YHTN6k0U1kdvHWaRpm4I8cEluGSAQy1iRW7hn0eZdFgZGijgFYPHEGjIrk7zdFet";
}
